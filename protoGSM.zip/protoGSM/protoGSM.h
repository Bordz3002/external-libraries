#ifndef protoGSM
#define protoGSM
#include <Arduino.h>
template <typename type=String>
class gsm_mini{
  public:
    String client_number;
    gsm_mini(void){};
    void begin(void){
      Serial3.begin(9600);
      Serial.println("initlializing...");
      delay(3000);
      Serial.println("initialization done");
    }
    bool valid_client_number(void){
      if(client_number.length()==0){  return false;}
      else{ return true;}
    }
    void validate_client_number(void){
      while(true){
        if(valid_client_number()!=true){
          Serial.println("please send something to validate client number");
          delay(500);
          recieve_sms();
        }
        else{
          Serial.println("client number retrieved: "+client_number);
          send_sms("client number retrieved: "+client_number);
          send_sms("thanks for using AUTONOMOUS LAWN MOWER");
          Serial.println("validation done");
          delay(5000);
          break;
        }
      }
    }
    void send_sms(const String message){
      delay(5000);
      String sms="AUTONOMOUS LAWN MOWER: "+message;
      Serial3.println("AT+CMGF=1");
      delay(1000);
      Serial3.println("AT+CMGS=\""+client_number+"\"");
      delay(2000);
      Serial3.print(sms);
      delay(1000);
      Serial3.write(26);
      Serial.println("sms : "+message);
    }
   type recieve_sms(void){
    Serial3.println("AT");
    delay(1000);
    Serial3.println("AT+CMGF=1");
    delay(1000);
    Serial3.println("AT+CNMI=2,2,0,0,0");
    delay(1000);
    String line, message;
    bool wait=false;
    while (true){
      if(Serial3.available()){
        line=Serial3.readStringUntil('\n');
        line.trim();
        if(line.startsWith("+CMT:")){
          int first_quote=line.indexOf('"');
          int second_quote=line.indexOf('"', first_quote+1);
          client_number=line.substring(first_quote+1, second_quote);
          wait=true;
          continue;
        }
        if(wait&& line.length()>0){
          message=line;
          return static_cast<type>(message);
        }
      }
    }
   }
};
#endif // protoGMS
